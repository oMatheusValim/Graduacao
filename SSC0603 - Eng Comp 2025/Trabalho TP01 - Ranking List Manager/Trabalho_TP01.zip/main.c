/*
Lista dinâmica encadeada dupla - 

ordenar do mais importante (inicio) para o menos importante (fim)
possível adicionar ou remover um item independente da posição

DADOS
    int ID
    string[15] NOME

PRINCIPAIS FUNÇÕES
    1. inserção no início
    2. inserção no final
    3. inserção antes ou depois do atual (cursos do buscar ID)
    4. buscar ID (mover o cursor)
    5. remover item buscado (ID, cursor atual move p/ anterior)
    6. move o cursor para o inicio
    7. move o cursor para o fim
    8. lista todos
    9. listar vizinhança do cursor (anterior, atual e proximo)
    10. exibir atual (cursor)

ENTRADA
° pedirá até que a entrada seja um 'X'

COMANDO:
    cmd = ['A', 'B', 'D', 'E', 'F', 'I', 'L', 'N', 'P', 'R', 'S', 'V', 'X']

    entrada.strip() - função que faz isso
    entrada.split("") - função que faz isso

    if (entrada[0] not in cmd){
        continue;
    }

    if ( entrada[0] == 'X'){
        break;
    }    

    switch (entrada[0]):
        case 'I':
            struct dados_lista dt;
            insere_inicio(li, dt, entrada[1]); 
            //li é o cursor, dt é o struct e entrada[1] é o ID, entrada[2] é nome
            break;

        case 'F':
            struct dados_lista dt;
            insere_final(li, dt, entrada[1], entrada[2]);
            break;

        case 'A':
            struct dados_lista dt;
            insere_antes_cursor(li, dt, entrada[1], entrada[2]);
            break;

        case 'D':
            struct dados_lista dt;
            insere_depois_cursor(li, dt, entrada[1], entrada[2]);
            break;

        case 'B':
            struct dados_lista dt;
            procurar_id(li, dt, entrada[1]);
            mudar_cursor(li, dt);
            break;

        case 'R':
            remove_nodo(li, dt)
            break;

        case 'S':
            posiciona_cursor_inicio(li, dt)
            break;

        case 'E':
            posiciona_cursor_fim(li, dt)
            break;

        case 'N':
            posiciona_cursor_nodoS(li, dt)
            break;

        case 'P':
            mostra_nodo(li, dt)
            break;

        case 'L':
            exibir_todos(li, dt)
            break;

        case 'V':
            exibe_vizinhos(li, dt)
            // mostra o nodo anterior, atual e proximo
            break;
*/

#include <stdio.h>
#include <string.h>
#include "lista_LDED.h"

int main() {
    Lista *li = cria_lista();
    char comando;
    RankingData dt;

    while (scanf(" %c", &comando) && comando != 'X') {
        switch (comando) {
            case 'I':
                scanf("%d %s", &dt.id, dt.nome);
                insere_lista_inicio(li, dt);
                break;
            case 'F':
                scanf("%d %s", &dt.id, dt.nome);
                insere_lista_final(li, dt);
                break;
            case 'A':
                scanf("%d %s", &dt.id, dt.nome);
                insere_lista_antes_cursor(li, dt);
                break;
            case 'D':
                scanf("%d %s", &dt.id, dt.nome);
                insere_lista_depois_cursor(li, dt);
                break;
            case 'B':
                scanf("%d", &dt.id);
                busca_lista_id(li, dt.id);
                break;
            case 'R':
                remove_lista_cursor(li);
                break;
            case 'S':
                move_cursor_inicio(li);
                break;
            case 'E':
                move_cursor_fim(li);
                break;
            case 'N':
                move_cursor_proximo(li);
                break;
            case 'P':
                exibe_lista_atual(li);
                break;
            case 'L':
                exibe_lista_toda(li);
                break;
            case 'V':
                exibe_lista_vizinhos(li);
                break;
            default:
                // Ignorar comandos inválidos, limpando o buffer de entrada
                {
                    char c;
                    while ((c = getchar()) != '\n' && c != EOF);
                }
                break;
        }
    }

    libera_lista(li);
    return 0;
}